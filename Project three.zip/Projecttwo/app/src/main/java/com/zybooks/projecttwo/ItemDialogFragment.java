package com.zybooks.projecttwo;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class ItemDialogFragment extends DialogFragment {

    public interface OnItemEnteredListener {
        void onItemEntered(String subjectText);
    }

    private OnItemEnteredListener mListener;

    @NonNull
    @Override
    public AlertDialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final EditText itemEditText = new EditText(requireActivity());
        itemEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        itemEditText.setMaxLines(1);


        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.item_name)
                .setView(itemEditText)
                .setPositiveButton(R.string.add, (dialog, whichButton) -> {
                    // Notify listener
                    String item = itemEditText.getText().toString();
                    mListener.onItemEntered(item);
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        Log.d("attach click", "clicked");
        mListener = (OnItemEnteredListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.d("detach click", "clicked");
        mListener = null;
    }




}
package com.zybooks.projecttwo.model;

import androidx.annotation.NonNull;

public class Item {

    //*************************VARIABLES*********************************
    private String name;
    private int quantity = 0;


    //*************************CONSTRUCTOR*******************************
    public Item(@NonNull String nameArg) {
        name = nameArg;
    }


    //*************************SETTERS**********************************
    public void setName(String nameArg){ name = nameArg; }
    public void setQuantity(int quantityArg) { quantity = quantityArg; }


    //**************************GETTERS*********************************
    public String getName(){ return name; }

    public int getQuantity(){ return quantity; }

    //*******************************INC/DEC-REMENTER**************************

    public void incrementQuantity() {
        quantity += 1;
    }

    public void decrementQuantity() {
        quantity -= 1;
        if (quantity < 0) {
            quantity = 0;
        }
    }
}

package com.zybooks.projecttwo;


import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;



public class PermissionActivity extends AppCompatActivity {

Switch SMS, push;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.myToolbar);
        setSupportActionBar(myToolbar);

        getSupportActionBar().setTitle("Permissions");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        SMS = findViewById(R.id.switchSMS);
        push = findViewById(R.id.switchPush);

        SMS.setOnClickListener(view -> {
            Toast.makeText(this, "SMS Enabled", Toast.LENGTH_SHORT).show();
        });

        push.setOnClickListener(view -> {
            Toast.makeText(this, "Push Enabled", Toast.LENGTH_SHORT).show();
        });

    }

}

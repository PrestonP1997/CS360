package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    //Declare variables
    EditText username, password;
    Button signUp, signIn;

    DBHelp DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Initialize variables
        username = findViewById(R.id.username_email);
        password = findViewById(R.id.password);
        signUp = findViewById(R.id.create_button);
        signIn = findViewById(R.id.login_button);
        DB = new DBHelp(this);

        // Sign up button lister, for making new accounts
        signUp.setOnClickListener(view -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            //Checks for empty fields
            if(user.equals("")||pass.equals("")) {
                Toast.makeText(LoginActivity.this, "Please check all fields", Toast.LENGTH_SHORT).show();
            } else {
                //Checks database for matching username
                boolean checkUser = DB.checkUserName(user);
                if (checkUser == false) {
                    //If the username or email isn't claimed, add the username and password to the database
                    boolean insert = DB.insertData(user, pass);
                    if (insert) {
                        Toast.makeText(LoginActivity.this, "Account Successfully created!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(LoginActivity.this, "User already exists, Sign in", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Sign in button listener, for signing in to an existing account
        signIn.setOnClickListener(view -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            //Checks for empty fields
            if(user.equals("")||pass.equals("")) {
                Toast.makeText(LoginActivity.this, "Please check all fields", Toast.LENGTH_SHORT).show();
            } else {
                //If the fields aren't empty, checks database for a matching email/password
                if(DB.checkUserPassword(user, pass) ) {
                    //If there is a match, start the main activity
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                } else{
                    //If there was no match, inform user
                    Toast.makeText(LoginActivity.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

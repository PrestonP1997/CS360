package com.zybooks.projecttwo;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.zybooks.projecttwo.model.Item;
import com.zybooks.projecttwo.viewmodel.ItemListViewModel;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class MainActivity extends AppCompatActivity
        implements ItemDialogFragment.OnItemEnteredListener {

    private ItemAdapter mItemAdapter;

    private RecyclerView mRecyclerView;

    private ItemListViewModel mItemListViewModel;


    private int[] mItemColors;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        Toolbar myToolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(myToolbar);

        mItemListViewModel = new ItemListViewModel(getApplication());
        mItemColors = getResources().getIntArray(R.array.itemColors);



        findViewById(R.id.add_item_button).setOnClickListener(view -> addItemClick());

        mRecyclerView = findViewById(R.id.item_recycler_view);
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        initializeUI(mItemListViewModel.getItems());
    }

    //******************************MENU CREATION**************************************
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        Log.d("MENUCREATION", "working menu");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.permissions){
            Intent intent = new Intent(this, PermissionActivity.class);
            startActivity(intent);
            Log.d("optionselected", "working");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //*********************ADD STARTER DATA AND INITIALIZE THE RECYCLER VIEW***************
    private void initializeUI(List<Item> itemList) {
        mItemAdapter = new ItemAdapter(itemList);
        mRecyclerView.setAdapter(mItemAdapter);
    }



//    //***************************ADD BUTTON AND ADDING ITEMS TO LIST********************
    //When the positive dialog button is pressed, a new item is created and added ot the list
    @Override
    public void onItemEntered(String text) {
        if (text.length() > 0) {
            Item item = new Item(text);
            mItemListViewModel.addItem(item);
            Toast.makeText(this, "Added " + text, Toast.LENGTH_SHORT).show();
        }
    }

    //Opens fragment that takes user input for adding an item to the application
    public void addItemClick() {
        ItemDialogFragment item = new ItemDialogFragment();
        item.show(getSupportFragmentManager(), "ITEM");
    }


    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemTextView;
        private final TextView mItemQuantityView;
        private View mCard;


        // Image buttons for incrementing (+), decrementing(-), and deleting items.
        private final ImageButton minusButton = itemView.findViewById(R.id.decrease);
        private final ImageButton plusButton = itemView.findViewById(R.id.increase);
        private final ImageButton deleteButton = itemView.findViewById(R.id.delete);


        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));

            //Increments quantity when plus button is tapped
            plusButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItem.incrementQuantity();
                    mItemAdapter.notifyDataSetChanged();
                }
            });

            //Decrements quantity when minus button it tapped
            minusButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mItem.decrementQuantity();
                    mItemAdapter.notifyDataSetChanged();
                }
            });

            //Deletes item when minus button it tapped
            deleteButton.setOnClickListener(v -> {
                mItemListViewModel.deleteItem(mItem);
                  mItemAdapter.notifyDataSetChanged();
            });

            mItemTextView = itemView.findViewById(R.id.item_text_view);
            mItemQuantityView = itemView.findViewById(R.id.item_quantity_text_view);
        }

        public void bind(Item item, int position) {
            mCard = itemView.findViewById(R.id.card);
            mItem = item;
            mItemTextView.setText(item.getName());
            Random rand = new Random();
            //update quantity here later

            mItemQuantityView.setText(Integer.toString(item.getQuantity()));
//            //update colors here
            int colorIndex = item.getName().length() % mItemColors.length;
            mCard.setBackgroundColor(mItemColors[colorIndex]);
        }

        @Override
        public void onClick(View view) {
            mItem.incrementQuantity();
        }

    }


    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {
        private List<Item> mItemList;
        public ItemAdapter(List<Item> items){ mItemList = items;}

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            holder.bind(mItemList.get(position), position);
        }

        @Override
        public int getItemCount(){
            return mItemList.size();
        }
    }
}




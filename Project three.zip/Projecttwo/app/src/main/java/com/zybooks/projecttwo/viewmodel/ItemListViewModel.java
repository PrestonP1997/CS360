package com.zybooks.projecttwo.viewmodel;

import android.app.Application;
import java.util.List;
import com.zybooks.projecttwo.model.Item;
import com.zybooks.projecttwo.repo.ItemRepository;

public class ItemListViewModel {

   private ItemRepository itemRepo;

    public ItemListViewModel(Application application) {
        itemRepo = ItemRepository.getInstance(application.getApplicationContext());
    }

    public List<Item> getItems() {return itemRepo.getItems();}

    public void addItem(Item item){ itemRepo.addItem(item);}

    public void deleteItem(Item item) {
        itemRepo.deleteItem(item);
    }
}

package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelp extends SQLiteOpenHelper {

    public DBHelp(Context context) {
        super(context, "Login.DataBase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        //creates a table with a username (primary key) and a password
        MyDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }

    public boolean insertData(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        //inserts matching username and password to the users table
        long result = MyDB.insert("users", null, contentValues);
        if (result == -1) {
            //if there was a failure return false
            return false;
        }
        else {
            //if successful, return true
            return true;
        }
    }

    public boolean checkUserName(String userName) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[] {userName});
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        else {
            return false;
        }
    }


    public boolean checkUserPassword(String userName, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?" , new String[] {userName, password});
        if(cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        else {
            return false;
        }
    }
}

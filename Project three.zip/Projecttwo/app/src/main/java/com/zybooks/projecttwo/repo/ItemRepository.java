package com.zybooks.projecttwo.repo;

import android.content.Context;
import com.zybooks.projecttwo.model.Item;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ItemRepository {

    private static ItemRepository mItemRepo;

    //final removed
    private List<Item> mItemList;


    public static ItemRepository getInstance(Context context) {
        if(mItemRepo == null) {
            mItemRepo = new ItemRepository(context);

        }
        return mItemRepo;
    }

    private ItemRepository(Context context) {
        mItemList = new ArrayList<>();
        addStarterItem();

    }

    private void addStarterItem() {
        Item pen = new Item("pen");
        pen.setQuantity(1);
        addItem(pen);

        Item shoe = new Item("shoe");
        shoe.setQuantity(30);
        addItem(shoe);

        Item knife = new Item("knife");
        knife.setQuantity(30);
        addItem(knife);

        Item blanket = new Item("blanket");
        blanket.setQuantity(30);
        addItem(blanket);

        Item string = new Item("string");
        string.setQuantity(30);
        addItem(string);

        Item jackets = new Item("jackets");
        jackets.setQuantity(30);
        addItem(jackets);

        Item socks = new Item("socks");
        socks.setQuantity(30);
        addItem(socks);

        Item fans = new Item("fans");
        fans.setQuantity(30);
        addItem(fans);

        Item keyboard = new Item("keyboard");
        keyboard.setQuantity(30);
        addItem(keyboard);

        Item mice = new Item("mice");
        mice.setQuantity(30);
        addItem(mice);

    }

    public void addItem(Item item) {
        mItemList.add(item); }


    public void deleteItem(Item item) {
        mItemList.remove(item); }

    public List<Item> getItems() {
        return mItemList; }
}
